#!/bin/sh
while [ true ]
do
   sleep 1
   /tmp/psutil-master/scripts/test/dist/nsrps
done
